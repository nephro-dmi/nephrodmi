from django.db import models

class Patient(models.Model):
    """
    Represents a patient with a unique ID and associated metadata.
    This model is for tracking purposes only and does not store images.
    """

    patient_id = models.CharField(max_length=255, unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    category = models.CharField(max_length=255)
    status = models.CharField(max_length=255, default='waiting for analysis to be completed')

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.category})"
class PatientImage(models.Model):
    """
    Represents an image associated with a patient.
    This model helps manage metadata related to images.
    """
    patient = models.ForeignKey(Patient, related_name='images', on_delete=models.CASCADE)
    image_url = models.URLField(max_length=1024)
    blob_name = models.CharField(max_length=255)
    upload_time = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=255, default='waiting for analysis to be completed')

    def __str__(self):
        return f"Image for {self.patient} - {self.blob_name}"
