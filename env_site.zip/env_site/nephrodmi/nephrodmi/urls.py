from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('get_image_url/<str:image_name>/', views.get_image_url, name='get_image_url'),
    path('update_image_status_flutter/<str:patient_id>/<str:image_id>/', views.update_image_status_flutter, name='update_image_status_flutter'),
    path('upload_image/<str:category>/<str:patient_id>/', views.upload_image, name='upload_image'),
]
