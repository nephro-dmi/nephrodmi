from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import firebase_admin
from firebase_admin import credentials, storage, firestore
from datetime import timedelta
import logging

# Initialize Firebase Admin SDK
if not firebase_admin._apps:
    cred = credentials.Certificate(
        r'C:\Users\USER\env_site\nephrodmi\nephrodmi-firebase-adminsdk-mkpz3-4549e25d8f.json'
    )
    firebase_admin.initialize_app(cred, {'storageBucket': "nephrodmi.appspot.com", 'databaseURL': 'https://eur3.firebaseio.com'})

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def home(request):
    """
    View to fetch and display patient images and details from Firebase Storage and Firestore.
    Updates the image status to 'analysis completed'.
    """
    try:
        # Get Firebase Storage bucket and Firestore client
        bucket = storage.bucket()
        db = firestore.client()

        # List of all categories to fetch from
        categories = [
            'biochimie', 'bacteriologie', 'parasitologie', 'virologie', 
            'imagerie', 'immunologie', 'hematologie', 'anatomopathologie'
        ]

        patient_data = []

        # Iterate over each category
        for category in categories:
            # Firestore path to fetch patient documents
            patients_ref = db.collection('patients').document(category).collection('patientList')
            patients_docs = patients_ref.stream()

            for patient_doc in patients_docs:
                patient_id = patient_doc.id  # Patient ID from Firestore

                # Fetch patient document data
                patient_data_dict = patient_doc.to_dict()
                
                # Fetch images using patient ID as folder path
                blobs = bucket.list_blobs(prefix=f'{patient_id}/')

                image_list = []
                for blob in blobs:
                    # Generate a signed URL for each blob
                    image_url = blob.generate_signed_url(timedelta(seconds=300), method='GET')

                    # Extract image ID from blob name (assuming blob name is the filename)
                    image_id = blob.name.split('/')[-1].split('.')[0]  # Assuming image names have extensions

                    # Update the status of the image in Firestore
                    image_ref = db.collection('patients').document(category).collection('patientList').document(patient_id).collection('images').document(image_id)

                    # Check if the image document exists
                    image_doc = image_ref.get()
                    if image_doc.exists:
                        image_data = image_doc.to_dict()

                        current_status = image_data.get('status', '')
                        if current_status != 'analysis completed':
                            image_ref.update({'status': 'analysis completed'})  
                        
                        # Fetch additional details
                        image_name = image_data.get('name', 'Unnamed Image')
                        image_description = image_data.get('description', 'No Description Available')
                        image_status = image_data.get('status', 'Unknown')

                        image_list.append({
                            'blob_name': blob.name,
                            'url': image_url,
                            'image_id': image_id,
                            'name': image_name,
                            'description': image_description,
                            'status': image_status,
                        })

                # Fetch and process driveLinks and firebaseLinks
                drive_links = [
                    {
                        'description': link.get('description', 'No Description'),
                        'link': link.get('link', ''),
                        'status': link.get('status', 'Unknown')
                    }
                    for link in patient_data_dict.get('driveLinks', [])
                ]

                firebase_links = [
                    {
                        'description': link.get('description', 'No Description'),
                        'link': link.get('link', ''),
                        'status': link.get('status', 'Unknown')
                    }
                    for link in patient_data_dict.get('firebaseLinks', [])
                ]

                # Update status in driveLinks
                for drive_link in drive_links:
                    if drive_link['status'] != 'analysis completed':
                        drive_link['status'] = 'analysis completed'

                # Update status in firebaseLinks
                for firebase_link in firebase_links:
                    if firebase_link['status'] != 'analysis completed':
                        firebase_link['status'] = 'analysis completed'

                # Save updated patient data back to Firestore
                patient_info_ref = db.collection('patients').document(category).collection('patientList').document(patient_id)
                patient_info_ref.update({
                    'driveLinks': drive_links,
                    'firebaseLinks': firebase_links
                })

                # Extract patient details to be included
                patient_details = {
                    'first_name': patient_data_dict.get('first name', 'N/A'),
                    'last_name': patient_data_dict.get('last name', 'N/A'),
                    'folderLink': patient_data_dict.get('folderLink', 'N/A'),
                    'requestCreatedBy': patient_data_dict.get('requestCreatedBy', []),
                    'supervisedBy': patient_data_dict.get('supervisedBy', [])
                }

                patient_data.append({
                    'id': patient_id,
                    'details': patient_details,
                    'images': image_list,
                    'drive_links': drive_links,
                    'firebase_links': firebase_links
                })

        return render(request, "home.html", {"patients": patient_data})

    except firebase_admin.exceptions.FirebaseError as fe:
        logger.error(f"Firebase error while fetching images: {fe}")
        return HttpResponse("Error fetching images from Firebase. Please try again later.", status=500)

    except Exception as e:
        logger.error(f"General error fetching images: {e}")
        return HttpResponse(f"An unexpected error occurred while fetching images: {e}", status=500)

def get_image_url(request, image_name):
    """
    Endpoint to generate a signed URL for an image in Firebase Storage.
    """
    try:
        bucket = storage.bucket()
        blob = bucket.blob(image_name)
        if not blob.exists():
            return HttpResponse(f"Blob {image_name} does not exist.", status=404)
        image_url = blob.generate_signed_url(timedelta(seconds=300), method='GET')
        return JsonResponse({"image_url": image_url})

    except firebase_admin.exceptions.FirebaseError as fe:
        logger.error(f"Firebase error generating URL: {fe}")
        return HttpResponse(f"Error generating URL for {image_name} from Firebase. Please try again later.", status=500)

    except Exception as e:
        logger.error(f"General error generating URL for {image_name}: {e}")
        return HttpResponse(f"An unexpected error occurred while generating URL for {image_name}: {e}", status=500)

def update_image_status_flutter(request, patient_id, image_id):
    """
    Endpoint for Flutter app to update image status in Firestore.
    """
    if request.method == 'POST':
        try:
            # Extract the new status from POST data, default to 'analysis completed'
            new_status = request.POST.get('status', 'analysis completed')

            db = firestore.client()
            image_ref = db.collection('patients').document('biochimie').collection('patientList').document(patient_id).collection('images').document(image_id)

            # Check if the image document exists
            if image_ref.get().exists:
                # Optionally check the current status to ensure correct transition
                current_status = image_ref.get().to_dict().get('status', '')
                if current_status == 'analysis on the way':
                    image_ref.update({'status': new_status})

            return JsonResponse({'message': 'Image status updated successfully', 'status': new_status})

        except firebase_admin.exceptions.FirebaseError as fe:
            logger.error(f"Firebase error updating image status: {fe}")
            return HttpResponse("Error updating image status in Firebase. Please try again later.", status=500)

        except Exception as e:
            logger.error(f"General error updating image status: {e}")
            return HttpResponse(f"An unexpected error occurred while updating image status: {e}", status=500)

    return HttpResponse("Method not allowed.", status=405)

def upload_image(request, category, patient_id):
    """
    Endpoint to upload an image to Firebase Storage and Firestore.
    """
    if request.method == 'POST':
        try:
            # Retrieve the uploaded image file
            image_file = request.FILES.get('image')
            if not image_file:
                return HttpResponse("No image file found in request.", status=400)

            file_name = image_file.name

            # Upload image to Firebase Storage
            bucket = storage.bucket()
            blob = bucket.blob(f'{patient_id}/{file_name}')  # Use patient ID as folder
            blob.upload_from_file(image_file)
            # Set blob to be publicly accessible
            blob.make_public()

            image_url = blob.public_url

            # Store image URL and initial status in Firestore
            db = firestore.client()
            image_ref = db.collection('patients').document(category).collection('patientList').document(patient_id).collection('images').document(file_name)
            image_ref.set({
                'url': image_url,
                'fileName': file_name,
                'status': 'waiting for analysis to be completed',
                'name': request.POST.get('name', 'Unnamed Image'),  # Accept name and description as additional fields
                'description': request.POST.get('description', 'No Description Available')
            })

            return JsonResponse({'message': 'Image uploaded successfully', 'image_url': image_url})

        except firebase_admin.exceptions.FirebaseError as fe:
            logger.error(f"Firebase error uploading image: {fe}")
            return HttpResponse("Error uploading image to Firebase. Please try again later.", status=500)

        except KeyError as ke:
            logger.error(f"Missing file error: {ke}")
            return HttpResponse("Image file is missing from request. Please check your request and try again.", status=400)

        except Exception as e:
            logger.error(f"General error uploading image: {e}")
            return HttpResponse(f"An unexpected error occurred while uploading the image: {e}", status=500)

    return HttpResponse("Method not allowed.", status=405)
